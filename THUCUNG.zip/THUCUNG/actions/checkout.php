<?php
session_start();
require_once "../config/database.php";

if(!isset($_SESSION['user_id'])){
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


// lấy customer
$sql = "SELECT id FROM customers WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();
$res = $stmt->get_result();
$customer = $res->fetch_assoc();

$customer_id = $customer['id'];


// tìm order giỏ hàng
$sql = "SELECT id FROM orders 
        WHERE customer_id=? 
        AND status='Giỏ hàng'
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$customer_id);
$stmt->execute();
$res = $stmt->get_result();
$order = $res->fetch_assoc();

if(!$order){
    echo "Giỏ hàng trống";
    exit();
}

$order_id = $order['id'];


// tính tổng tiền
$sql = "SELECT SUM(price_at_time * quantity) as total
        FROM order_details
        WHERE order_id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$order_id);
$stmt->execute();
$res = $stmt->get_result();
$data = $res->fetch_assoc();

$total = $data['total'];


// cập nhật order
$sql = "UPDATE orders 
        SET total=?, status='Chờ xử lý'
        WHERE id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("di",$total,$order_id);
$stmt->execute();


// tạo payment
$sql = "INSERT INTO payments(order_id,method,status)
        VALUES(?, 'COD', 'Chưa thanh toán')";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$order_id);
$stmt->execute();


// chuyển về trang đơn hàng
header("Location: ../views/orders.php");
exit();

?>