<?php

include("../config/database.php");

if(isset($_GET['id'])){

$id = $_GET['id'];

$sql = "DELETE FROM pets WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Xóa thú cưng thành công');
window.location.href='../admin/pets.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}

?>