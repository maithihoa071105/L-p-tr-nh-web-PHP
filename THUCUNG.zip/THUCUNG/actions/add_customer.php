<?php

include("../config/database.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){

$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];

$sql = "INSERT INTO customers(full_name,phone,address)
VALUES('$full_name','$phone','$address')";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Thêm khách hàng thành công');
window.location.href='../admin/customers.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}

?>