<?php
session_start();
require_once "../config/database.php";

$pet_id = $_POST['pet_id'];
$quantity = 1;

if(!isset($_SESSION['user_id'])){
echo "login_required";
exit();
}

$user_id = $_SESSION['user_id'];

// lấy customer_id
$sql = "SELECT id FROM customers WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();
$result = $stmt->get_result();
$customer = $result->fetch_assoc();
$customer_id = $customer['id'];

// tạo đơn tạm
$sql = "INSERT INTO orders(customer_id,total,status) VALUES(?,0,'Giỏ hàng')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$customer_id);
$stmt->execute();

$order_id = $conn->insert_id;

// lấy giá thú cưng
$sql = "SELECT price FROM pets WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$pet_id);
$stmt->execute();
$result = $stmt->get_result();
$pet = $result->fetch_assoc();
$price = $pet['price'];

// thêm vào order_details
$sql = "INSERT INTO order_details(order_id,pet_id,price_at_time,quantity)
VALUES(?,?,?,?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iidi",$order_id,$pet_id,$price,$quantity);
$stmt->execute();

echo "added";
?>