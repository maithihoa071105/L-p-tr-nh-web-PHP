<?php

include("../config/database.php");

if($_SERVER["REQUEST_METHOD"]=="POST"){

$id = $_POST['id'];
$name = $_POST['name'];
$category_id = $_POST['category_id'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$description = $_POST['description'];
$status = $_POST['status'];

$sql = "UPDATE pets SET
name='$name',
category_id='$category_id',
price='$price',
stock='$stock',
description='$description',
status='$status'
WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Cập nhật thú cưng thành công');
window.location.href='../admin/pets.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}
?>