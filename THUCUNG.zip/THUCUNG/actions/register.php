<?php

session_start();
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

$ho = $_POST['ho'];
$ten = $_POST['ten'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$repassword = $_POST['repassword'];

$fullname = $ho . " " . $ten;

// kiểm tra mật khẩu
if ($password != $repassword) {

echo "<script>
alert('Mật khẩu xác nhận không đúng');
history.back();
</script>";
exit();

}

// mã hóa mật khẩu
$hashPassword = password_hash($password, PASSWORD_DEFAULT);

// kiểm tra email tồn tại
$sql_check = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("s",$email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

echo "<script>
alert('Email đã tồn tại');
history.back();
</script>";
exit();

}

// thêm vào bảng users
$sql = "INSERT INTO users(username,password,role,status)
VALUES(?,?,0,1)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss",$email,$hashPassword);

if ($stmt->execute()) {

$user_id = $stmt->insert_id;

// thêm vào bảng customers
$sql2 = "INSERT INTO customers(user_id,full_name,phone)
VALUES(?,?,?)";

$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("iss",$user_id,$fullname,$phone);
$stmt2->execute();

echo "<script>
alert('Đăng ký thành công');
window.location.href='../views/login.php';
</script>";

} else {

echo "<script>
alert('Đăng ký thất bại');
history.back();
</script>";

}

}

?>