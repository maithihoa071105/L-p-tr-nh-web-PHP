<?php

include("../config/database.php");

if($_SERVER["REQUEST_METHOD"]=="POST"){

$name = $_POST['name'];
$category_id = $_POST['category_id'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$description = $_POST['description'];
$status = $_POST['status'];

$sql = "INSERT INTO pets(name,category_id,price,stock,description,status)
VALUES('$name','$category_id','$price','$stock','$description','$status')";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Thêm thú cưng thành công');
window.location.href='../admin/pets.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}
?>