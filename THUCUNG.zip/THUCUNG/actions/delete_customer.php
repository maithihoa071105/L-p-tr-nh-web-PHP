<?php

include("../config/database.php");

if(isset($_GET['id'])){

$id = $_GET['id'];

$sql = "DELETE FROM customers WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Xóa khách hàng thành công');
window.location.href='../admin/customers.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}

?>