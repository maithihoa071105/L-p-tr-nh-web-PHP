<?php
include("../config/database.php");

$id=$_GET['id'];

$sql="DELETE FROM orders WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Xóa đơn hàng thành công');
window.location.href='../admin/orders.php';
</script>";
}
?>