<?php

session_start();
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Chuẩn bị câu lệnh SQL
    $sql = "SELECT * FROM users WHERE username = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // phân quyền
            if ($user['role'] == 1) {

                header("Location: ../admin/dashboard.php");

            } else {

                header("Location: ../index.php");

            }

        } else {

            $_SESSION['error'] = "Sai mật khẩu!";
            header("Location: ../views/auth.php");

        }

    } else {

        $_SESSION['error'] = "Tài khoản không tồn tại!";
        header("Location: ../views/auth.php");

    }

}
?>