<?php

include("../config/database.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){

$id = $_POST['id'];
$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];

$sql = "UPDATE customers
SET
full_name='$full_name',
phone='$phone',
address='$address'
WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Cập nhật khách hàng thành công');
window.location.href='../admin/customers.php';
</script>";
}else{
echo "Lỗi: ".mysqli_error($conn);
}

}

?>