<?php
session_start();
require_once "../config/database.php";

$user_id = $_SESSION['user_id'];

$fullname = $_POST['fullname'];
$phone = $_POST['phone'];
$address = $_POST['address'];

$sql = "UPDATE customers 
        SET full_name=?, phone=?, address=?
        WHERE user_id=?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi",$fullname,$phone,$address,$user_id);
$stmt->execute();

echo "ok";
?>