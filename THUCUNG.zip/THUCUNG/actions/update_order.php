<?php
include("../config/database.php");

$id=$_POST['id'];
$status=$_POST['status'];

$sql="UPDATE orders SET status='$status' WHERE id='$id'";

if(mysqli_query($conn,$sql)){
echo "<script>
alert('Cập nhật thành công');
window.location.href='../admin/orders.php';
</script>";
}
?>