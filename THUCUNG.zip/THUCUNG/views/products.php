<?php
session_start();
require_once "../config/database.php";
?>
<!doctype html>
<html lang="vi" class="h-full">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Shop - Thú Cưng Đáng Yêu</title>
  <script src="https://cdn.tailwindcss.com/3.4.17"></script>
  <script src="/_sdk/element_sdk.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&amp;family=Nunito:wght@400;600;700;800&amp;display=swap" rel="stylesheet">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            'pastel-pink': '#FFE4EC',
            'pastel-pink-dark': '#FFB6C8',
            'pastel-cream': '#FFF5F7',
            'pastel-lavender': '#F0E6EF',
            'text-dark': '#5D4E5C',
            'text-light': '#8B7A8A'
          },
          fontFamily: {
            'heading': ['Nunito', 'sans-serif'],
            'body': ['Quicksand', 'sans-serif']
          }
        }
      }
    }
  </script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    
    .app-wrapper {
      min-height: 100%;
      width: 100%;
    }
    
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
    }
    
    @keyframes pulse-soft {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }
    
    @keyframes shimmer {
      0% { background-position: -200% 0; }
      100% { background-position: 200% 0; }
    }
    
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    @keyframes wiggle {
      0%, 100% { transform: rotate(-3deg); }
      50% { transform: rotate(3deg); }
    }
    
    .float-animation {
      animation: float 3s ease-in-out infinite;
    }
    
    .pulse-animation {
      animation: pulse-soft 2s ease-in-out infinite;
    }
    
    .shimmer-btn {
      background: linear-gradient(90deg, #FFB6C8 0%, #FFCDD8 50%, #FFB6C8 100%);
      background-size: 200% 100%;
      animation: shimmer 3s linear infinite;
    }
    
    .fade-in-up {
      animation: fadeInUp 0.6s ease-out forwards;
    }
    
    .wiggle-hover:hover {
      animation: wiggle 0.3s ease-in-out;
    }
    
    .glass-effect {
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
    }
    
    .gradient-border {
      background: linear-gradient(135deg, #FFB6C8, #F0E6EF, #FFE4EC);
      padding: 2px;
      border-radius: 1rem;
    }
    
    .paw-pattern {
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cg fill='%23FFB6C8' fill-opacity='0.15'%3E%3Cellipse cx='30' cy='35' rx='8' ry='10'/%3E%3Ccircle cx='18' cy='22' r='5'/%3E%3Ccircle cx='42' cy='22' r='5'/%3E%3Ccircle cx='14' cy='35' r='4'/%3E%3Ccircle cx='46' cy='35' r='4'/%3E%3C/g%3E%3C/svg%3E");
    }
    
    .dropdown-menu {
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
    }
    
    .dropdown:hover .dropdown-menu {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    
    .pet-card:hover {
      transform: translateY(-8px);
    }
    
    .pet-card {
      transition: all 0.3s ease;
    }
    
    .nav-link {
      position: relative;
    }
    
    .nav-link::after {
      content: '';
      position: absolute;
      bottom: -4px;
      left: 50%;
      width: 0;
      height: 3px;
      background: linear-gradient(90deg, #FFB6C8, #FF8FAB);
      border-radius: 2px;
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }
    
    .nav-link:hover::after {
      width: 100%;
    }
    
    .search-input:focus {
      box-shadow: 0 0 0 3px rgba(255, 182, 200, 0.4);
    }
    
    .blob {
      border-radius: 50%;
      filter: blur(40px);
      opacity: 0.6;
      position: absolute;
      z-index: 0;
    }
  </style>
  <style>body { box-sizing: border-box; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
 </head>
 <body class="h-full font-body text-text-dark">
  <div class="app-wrapper bg-pastel-cream paw-pattern overflow-auto">

<header class="glass-effect sticky top-0 z-50 border-b border-pastel-pink-dark/20">

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

<div class="flex items-center justify-between h-20">

<!-- LOGO -->
<a href="index.php" class="flex items-center gap-3 group">

<div class="w-12 h-12 bg-gradient-to-br from-pastel-pink-dark to-pink-400 rounded-2xl flex items-center justify-center shadow-lg">

<svg class="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24">
<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
</svg>

</div>

<span class="font-heading font-extrabold text-2xl text-text-dark">
Pet Shop
</span>

</a>


<!-- SEARCH -->
<form action="search.php" method="GET" class="hidden md:block w-96">

<div class="relative">

<input
type="text"
name="keyword"
placeholder="Tìm kiếm..."
class="search-input w-full py-3 px-5 pr-12 rounded-full border-2 border-pastel-pink-dark/30 bg-white/80 text-text-dark placeholder-text-light focus:outline-none focus:border-pastel-pink-dark transition-all duration-300"
>

<button type="submit"
class="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-gradient-to-r from-pastel-pink-dark to-pink-400 rounded-full flex items-center justify-center">

<svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
</svg>

</button>

</div>

</form>


<!-- MENU -->
<nav class="hidden lg:flex items-center gap-8">
<a href="/THUCUNG/index.php" class="nav-link whitespace-nowrap font-semibold text-text-dark hover:text-pink-500 transition-colors duration-300 flex items-center gap-2">
Trang chủ
</a>

<a href="products.php" class="nav-link whitespace-nowrap font-semibold text-text-dark hover:text-pink-500 transition-colors duration-300">
Sản phẩm
</a>

<a href="orders.php" class="nav-link whitespace-nowrap font-semibold text-text-dark hover:text-pink-500 transition-colors duration-300">
Đơn hàng
</a>

<a href="cart.php" class="nav-link whitespace-nowrap font-semibold text-text-dark hover:text-pink-500 transition-colors duration-300">
Giỏ hàng🛒
</a>


<!-- ACCOUNT -->
<div class="dropdown relative group">

<button class="nav-link font-semibold text-text-dark hover:text-pink-500 transition-colors duration-300 flex items-center gap-2">

<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
</svg>

<?php
if(isset($_SESSION['username'])){
echo $_SESSION['username'];
}else{
echo "Tài khoản";
}
?>
<svg class="w-4 h-4 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
d="M19 9l-7 7-7-7"/>
</svg>

</button>


<div class="dropdown-menu absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-pastel-pink-dark/20 overflow-hidden hidden group-hover:block">

<div class="p-2">

<?php if(isset($_SESSION['username'])){ ?>

<a href="account.php" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-pastel-pink/50 transition-colors duration-200">
Thông tin tài khoản
</a>

<a href="orders.php" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-pastel-pink/50 transition-colors duration-200">
Đơn hàng của tôi
</a>

<div class="border-t border-pastel-pink-dark/20 my-2"></div>

<a href="/THUCUNG/logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-red-50 transition-colors duration-200 text-red-500">
Đăng xuất
</a>

<?php } else { ?>

<a href="auth.php" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-pastel-pink/50 transition-colors duration-200">
Đăng nhập
</a>

<a href="register.php" class="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-pastel-pink/50 transition-colors duration-200">
Đăng ký
</a>

<?php } ?>

</div>

</div>

</div>

</nav>

</div>

</div>

</header>
  <?php
require_once "../config/database.php";

$sql = "SELECT * FROM pets WHERE status = 1";
$result = $conn->query($sql);
?>

<section class="max-w-7xl mx-auto px-6 py-12">

<h2 class="text-3xl font-bold text-center mb-10 text-gray-800">
Thú cưng nổi bật
</h2>

<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

<?php while($row = $result->fetch_assoc()) { ?>

<div class="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition duration-300 flex flex-col">

<!-- ảnh -->
<div class="h-52 w-full overflow-hidden">
<img 
src="../images/<?php echo $row['image']; ?>"
class="w-full h-full object-cover"
alt="<?php echo $row['name']; ?>">
</div>

<!-- nội dung -->
<div class="p-4 flex flex-col flex-grow">

<h3 class="text-lg font-semibold text-gray-800 mb-2 text-center">
<?php echo $row['name']; ?>
</h3>

<p class="text-pink-500 font-bold text-center mb-4">
<?php echo number_format($row['price']); ?> VNĐ
</p>

<div class="mt-auto flex gap-3">

<a href="pet_detail.php?id=<?php echo $row['id']; ?>"
class="flex-1 h-12 flex items-center justify-center 
border-2 border-pink-300 text-pink-400 
rounded-xl font-semibold hover:bg-pink-50 transition">

Chi tiết

</a>

<button onclick="addToCart(<?php echo $row['id']; ?>)"
class="flex-1 h-12 flex items-center justify-center 
bg-pink-300 text-white 
rounded-xl font-semibold hover:bg-pink-400 transition">

Thêm giỏ

</button>

</div>

</div>

</div>

<?php } ?>

</div>

</section>



   <footer class="bg-text-dark text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
     <div class="py-12 grid md:grid-cols-4 gap-8">
      <div class="md:col-span-1">
       <div class="flex items-center gap-3 mb-4">
        <div class="w-12 h-12 bg-gradient-to-br from-pastel-pink-dark to-pink-400 rounded-2xl flex items-center justify-center">
         <svg class="w-7 h-7 text-white" fill="currentColor" viewbox="0 0 24 24">
          <ellipse cx="12" cy="14" rx="3" ry="4" /> <circle cx="8" cy="9" r="2" /> <circle cx="16" cy="9" r="2" /> <circle cx="6" cy="13" r="1.5" /> <circle cx="18" cy="13" r="1.5" />
         </svg>
        </div><span class="font-heading font-extrabold text-2xl">Pet Paradise</span>
       </div>
       <p class="text-white/70 mb-4">Nơi kết nối tình yêu thương giữa bạn và những người bạn bốn chân đáng yêu nhất! 🐾💕</p>
       <div class="flex gap-3"><a href="#" class="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-pink-500 transition-colors duration-300">
         <svg class="w-5 h-5" fill="currentColor" viewbox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
         </svg></a> <a href="#" class="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-pink-500 transition-colors duration-300">
         <svg class="w-5 h-5" fill="currentColor" viewbox="0 0 24 24">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
         </svg></a> <a href="#" class="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-pink-500 transition-colors duration-300">
         <svg class="w-5 h-5" fill="currentColor" viewbox="0 0 24 24">
          <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417a9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
         </svg></a>
       </div>
      </div>
      <div>
       <h4 class="font-heading font-bold text-lg mb-4">Liên Kết Nhanh</h4>
       <ul class="space-y-3">
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">Trang chủ</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">Sản phẩm</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">Về chúng tôi</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">Blog</a></li>
       </ul>
      </div>
      <div>
       <h4 class="font-heading font-bold text-lg mb-4">Danh Mục</h4>
       <ul class="space-y-3">
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">🐕 Chó cưng</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">🐈 Mèo cưng</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">🐰 Thỏ bông</a></li>
        <li><a href="#" class="text-white/70 hover:text-pink-400 transition-colors duration-300">🐹 Hamster</a></li>
       </ul>
      </div>
      <div>
       <h4 class="font-heading font-bold text-lg mb-4">Liên Hệ</h4>
       <ul class="space-y-3">
        <li class="flex items-center gap-3 text-white/70">
         <svg class="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewbox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
         </svg> 123 Đường ABC, Quận 1, TP.HCM</li>
        <li class="flex items-center gap-3 text-white/70">
         <svg class="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewbox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
         </svg> 0123 456 789</li>
        <li class="flex items-center gap-3 text-white/70">
         <svg class="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewbox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
         </svg> hello@petparadise.vn</li>
       </ul>
      </div>
     </div>
     <div class="py-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
      <p id="footer-text" class="text-white/50 text-sm text-center md:text-left">© 2025 Pet Paradise. Tất cả quyền được bảo lưu. Made with 💕 for pet lovers.</p>
      <div class="flex items-center gap-6 text-sm"><a href="#" class="text-white/50 hover:text-pink-400 transition-colors duration-300">Chính sách bảo mật</a> <a href="#" class="text-white/50 hover:text-pink-400 transition-colors duration-300">Điều khoản sử dụng</a>
      </div>
     </div>
    </div>
   </footer>
  </div>
  <script>
    const defaultConfig = {
      site_name: 'Pet Paradise',
      hero_title: 'Tìm Người Bạn Đồng Hành Hoàn Hảo',
      hero_subtitle: 'Khám phá thế giới thú cưng đáng yêu với hàng ngàn bé cún, mèo và các loài thú cưng độc đáo đang chờ đợi bạn! 🐶🐱🐰',
      footer_text: '© 2025 Pet Paradise. Tất cả quyền được bảo lưu. Made with 💕 for pet lovers.',
      primary_color: '#FFB6C8',
      secondary_color: '#FFF5F7',
      text_color: '#5D4E5C',
      accent_color: '#FF8FAB',
      font_family: 'Quicksand',
      font_size: 16
    };

    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    mobileMenuBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });

    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange: async (config) => {
          const siteNameEl = document.getElementById('site-name');
          if (siteNameEl) {
            siteNameEl.textContent = config.site_name || defaultConfig.site_name;
          }
          
          const heroTitleEl = document.getElementById('hero-title');
          if (heroTitleEl) {
            const title = config.hero_title || defaultConfig.hero_title;
            heroTitleEl.innerHTML = title.replace(/(Đồng Hành|Hoàn Hảo)/g, '<span class="bg-gradient-to-r from-pink-500 via-rose-400 to-pink-400 bg-clip-text text-transparent">$1</span>');
          }
          
          const heroSubtitleEl = document.getElementById('hero-subtitle');
          if (heroSubtitleEl) {
            heroSubtitleEl.textContent = config.hero_subtitle || defaultConfig.hero_subtitle;
          }
          
          const footerTextEl = document.getElementById('footer-text');
          if (footerTextEl) {
            footerTextEl.textContent = config.footer_text || defaultConfig.footer_text;
          }
          
          const fontFamily = config.font_family || defaultConfig.font_family;
          document.body.style.fontFamily = `${fontFamily}, Quicksand, sans-serif`;
          
          const fontSize = config.font_size || defaultConfig.font_size;
          document.documentElement.style.fontSize = `${fontSize}px`;
          
          const primaryColor = config.primary_color || defaultConfig.primary_color;
          const secondaryColor = config.secondary_color || defaultConfig.secondary_color;
          const textColor = config.text_color || defaultConfig.text_color;
          const accentColor = config.accent_color || defaultConfig.accent_color;
          
          document.documentElement.style.setProperty('--primary-color', primaryColor);
          document.documentElement.style.setProperty('--secondary-color', secondaryColor);
          document.documentElement.style.setProperty('--text-color', textColor);
          document.documentElement.style.setProperty('--accent-color', accentColor);
        },
        mapToCapabilities: (config) => ({
          recolorables: [
            {
              get: () => config.secondary_color || defaultConfig.secondary_color,
              set: (value) => {
                config.secondary_color = value;
                window.elementSdk.setConfig({ secondary_color: value });
              }
            },
            {
              get: () => config.primary_color || defaultConfig.primary_color,
              set: (value) => {
                config.primary_color = value;
                window.elementSdk.setConfig({ primary_color: value });
              }
            },
            {
              get: () => config.text_color || defaultConfig.text_color,
              set: (value) => {
                config.text_color = value;
                window.elementSdk.setConfig({ text_color: value });
              }
            },
            {
              get: () => config.accent_color || defaultConfig.accent_color,
              set: (value) => {
                config.accent_color = value;
                window.elementSdk.setConfig({ accent_color: value });
              }
            }
          ],
          borderables: [],
          fontEditable: {
            get: () => config.font_family || defaultConfig.font_family,
            set: (value) => {
              config.font_family = value;
              window.elementSdk.setConfig({ font_family: value });
            }
          },
          fontSizeable: {
            get: () => config.font_size || defaultConfig.font_size,
            set: (value) => {
              config.font_size = value;
              window.elementSdk.setConfig({ font_size: value });
            }
          }
        }),
        mapToEditPanelValues: (config) => new Map([
          ['site_name', config.site_name || defaultConfig.site_name],
          ['hero_title', config.hero_title || defaultConfig.hero_title],
          ['hero_subtitle', config.hero_subtitle || defaultConfig.hero_subtitle],
          ['footer_text', config.footer_text || defaultConfig.footer_text]
        ])
      });
    }
  </script>
  
<script>

function addToCart(id){

fetch("../actions/add_cart.php",{
method:"POST",
headers:{
"Content-Type":"application/x-www-form-urlencoded"
},
body:"pet_id="+id
})
.then(res=>res.text())
.then(data=>{

if(data=="login_required"){
alert("Bạn cần đăng nhập");
window.location.href="auth.php";
}

if(data=="added"){
alert("Đã thêm vào giỏ hàng 🐾");
}

})

}

</script>

 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9da915b6f5854bac',t:'MTc3MzIxNjY0OS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>