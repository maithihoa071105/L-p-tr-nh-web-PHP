<?php
session_start();
require_once "../config/database.php";

$id = $_GET['id'];

$sql = "SELECT * FROM pets WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();
$pet = $result->fetch_assoc();
?>

<div class="max-w-6xl mx-auto py-12">

<div class="grid md:grid-cols-2 gap-10 items-center">

<!-- Ảnh sản phẩm -->

<div class="bg-white rounded-3xl shadow-xl p-6">

<img src="../images/<?php echo $pet['image']; ?>"
class="w-full h-[400px] object-cover rounded-2xl hover:scale-105 transition duration-500">

</div>


<!-- Thông tin sản phẩm -->

<div class="bg-white rounded-3xl shadow-xl p-8">

<h2 class="text-3xl font-bold text-gray-700 mb-4">
<?php echo $pet['name']; ?>
</h2>

<p class="text-2xl text-pink-400 font-bold mb-6">
<?php echo number_format($pet['price']); ?> VNĐ
</p>

<p class="text-gray-500 leading-relaxed mb-6">
<?php echo $pet['description']; ?>
</p>

<div class="flex items-center gap-3 mb-6">

<span class="px-4 py-2 bg-green-100 text-green-600 rounded-full text-sm">

✔ Còn hàng

</span>

<span class="text-gray-400 text-sm">
Kho: <?php echo $pet['stock']; ?>
</span>

</div>


<!-- Nút -->

<div class="grid grid-cols-2 gap-4">

<button onclick="addToCart(<?php echo $pet['id']; ?>)"
class="bg-pink-300 hover:bg-pink-400 text-white py-3 rounded-xl text-lg font-semibold transition">

🛒 Thêm giỏ

</button>

<a href="products.php"
class="text-center border border-pink-300 text-pink-400 py-3 rounded-xl hover:bg-pink-50 font-semibold">

⬅ Quay lại

</a>

</div>

</div>

</div>

</div>



<script>

function addToCart(id)
{

fetch("../actions/add_to_cart.php?id="+id)

.then(res=>res.text())

.then(data=>{

alert("Đã thêm vào giỏ hàng 🛒");

});

}

</script>