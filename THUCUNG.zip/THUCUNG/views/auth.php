<!doctype html>
<html lang="vi">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Shop - Đăng Nhập &amp; Đăng Ký</title>
  <script src="https://cdn.tailwindcss.com/3.4.17"></script>
  <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            width: 100%;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #ffe8f3 0%, #ffd9e8 100%);
            overflow: hidden;
        }

        .container-auth {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-wrapper {
            display: flex;
            width: 100%;
            height: 100%;
            background: transparent;
            border-radius: 0;
            box-shadow: none;
            overflow: hidden;
            animation: slideIn 0.6s ease-out;
            justify-content: center;
            align-items: center;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-left {
            flex: 1;
            background: linear-gradient(135deg, #ffb3d9 0%, #ffa0c4 100%);
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }

        .auth-left::before {
            content: '🐾';
            position: absolute;
            font-size: 120px;
            opacity: 0.1;
            top: -20px;
            right: -20px;
        }

        .auth-left::after {
            content: '🐾';
            position: absolute;
            font-size: 80px;
            opacity: 0.1;
            bottom: -10px;
            left: -10px;
        }

        .auth-left-content {
            position: relative;
            z-index: 1;
            text-align: center;
        }

        .pet-icon {
            font-size: 80px;
            margin-bottom: 20px;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .auth-left h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 15px;
        }

        .auth-left p {
            font-size: 15px;
            opacity: 0.9;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .feature-list {
            text-align: left;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }

        .feature-item::before {
            content: '✓';
            font-weight: bold;
            font-size: 18px;
        }

        .auth-right {
            flex: 0 0 auto;
            width: 100%;
            max-width: 420px;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(255, 143, 179, 0.15);
        }

        .tabs {
            display: flex;
            gap: 0;
            margin-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
        }

        .tab-btn {
            flex: 1;
            padding: 15px 0;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            color: #999;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            position: relative;
            top: 2px;
        }

        .tab-btn.active {
            color: #ff8fb3;
            border-bottom-color: #ff8fb3;
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.4s ease;
        }

        .tab-content.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .form-group input:focus {
            outline: none;
            border-color: #ff8fb3;
            box-shadow: 0 0 0 3px rgba(255, 143, 179, 0.1);
        }

        .form-group input::placeholder {
            color: #999;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .remember-forgot input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #ff8fb3;
        }

        .forgot-link {
            color: #ff8fb3;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
            transition: color 0.3s;
        }

        .forgot-link:hover {
            color: #ffb3d9;
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff8fb3 0%, #ffa0c4 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255, 143, 179, 0.3);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .signup-text {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }

        .signup-text a {
            color: #ff8fb3;
            text-decoration: none;
            font-weight: 700;
            cursor: pointer;
            transition: color 0.3s;
        }

        .signup-text a:hover {
            color: #ffb3d9;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            color: #ccc;
            font-size: 13px;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e0e0e0;
        }

        .divider::before {
            margin-right: 10px;
        }

        .divider::after {
            margin-left: 10px;
        }

        .social-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 20px;
        }

        .social-btn {
            padding: 12px;
            border: 2px solid #e0e0e0;
            background: white;
            border-radius: 10px;
            cursor: pointer;
            font-size: 22px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .social-btn:hover {
            border-color: #667eea;
            background: #f9f9f9;
            transform: translateY(-2px);
        }
        
        .social-btn.google {
            color: #4285f4;
        }
        
        .social-btn.facebook {
            color: #1877f2;
        }

        @media (max-width: 768px) {
            .auth-wrapper {
                flex-direction: column;
                max-height: none;
            }

            .auth-left {
                display: none;
            }

            .auth-right {
                max-width: 100%;
                border-radius: 0;
                box-shadow: none;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .pet-icon {
                font-size: 60px;
            }
        }
    </style>
  <style>body { box-sizing: border-box; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="/_sdk/element_sdk.js" type="text/javascript"></script>
 </head>
 <body>
  <div class="container-auth">
   <div class="auth-wrapper">
    <!-- Left Side -->
    <div class="auth-left">
     <div class="auth-left-content">
      <div class="pet-icon">
       🐶
      </div>
      <h2>PetShop Pro</h2>
      <p>Thú cưng yêu thương</p>
      <?php
session_start();
if(isset($_SESSION['error'])){
?>
<div style="color:red;text-align:center;margin-bottom:10px;">
    <?php 
        echo $_SESSION['error']; 
        unset($_SESSION['error']);
    ?>
</div>
<?php } ?>
      <div class="feature-list">
       <div class="feature-item">
        Hàng ngàn thú cưng
       </div>
       <div class="feature-item">
        Dịch vụ chuyên nghiệp
       </div>
       <div class="feature-item">
        Giao hàng nhanh
       </div>
       <div class="feature-item">
        Hỗ trợ 24/7
       </div>
      </div>
     </div>
    </div><!-- Right Side -->
    <div class="auth-right">
     <!-- PetShop Header -->
     <div style="text-align: center; margin-bottom: 30px;">
      <h1 style="font-size: 32px; font-weight: 800; color: #ff8fb3; margin: 0;">PetShop</h1>
      <p style="font-size: 13px; color: #999; margin-top: 5px;">Thú cưng yêu thương</p>
     </div><!-- Login Form -->
     <div>
      <form action="../actions/login.php" method="POST">
       <div class="form-group">
        <label>Email hoặc Số điện thoại</label> <input type="text" name="username" placeholder="Nhập email hoặc số điện thoại" required>
       </div>
       <div class="form-group">
        <label>Mật khẩu</label> <input type="password" name="password" placeholder="Nhập mật khẩu" required>
       </div>
       <div class="remember-forgot">
        <label style="display: flex; align-items: center; gap: 8px; margin: 0; cursor: pointer;"> <input type="checkbox"> <span>Nhớ mật khẩu</span> </label> <a href="#" class="forgot-link">Quên mật khẩu?</a>
       </div><button type="submit" class="submit-btn">Đăng Nhập</button>
      </form>
      <div class="divider">
       Hoặc
      </div>
      <div class="social-buttons">
       <button class="social-btn google" title="Đăng nhập với Google">G</button> <button class="social-btn facebook" title="Đăng nhập với Facebook">f</button>
      </div>
     <div class="signup-text">
Chưa có tài khoản? 
<a href="register.php">Đăng ký ngay</a>
</div>
     <div class="tab-content" id="signup">
      
      <div class="signup-text">
       Đã có tài khoản? <a onclick="switchTab('login')">Đăng nhập tại đây</a>
      </div>
     </div>
    </div>
   </div>
  </div>
  <script>
        function switchTab(tab) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelectorAll('.tab-btn').forEach(el => {
                el.classList.remove('active');
            });

            // Show selected tab
            document.getElementById(tab).classList.add('active');
            event.target.classList.add('active');
        }

        function handleLogin(e) {
            e.preventDefault();
            const successMsg = document.createElement('div');
            successMsg.textContent = '✓ Đăng nhập thành công!';
            successMsg.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #4caf50;
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                font-weight: 600;
                animation: slideIn 0.4s ease;
                z-index: 1000;
            `;
            document.body.appendChild(successMsg);
            setTimeout(() => successMsg.remove(), 3000);
            e.target.reset();
        }

        function handleSignup(e) {
            e.preventDefault();
            const successMsg = document.createElement('div');
            successMsg.textContent = '✓ Đăng ký thành công! Vui lòng đăng nhập.';
            successMsg.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #4caf50;
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                font-weight: 600;
                animation: slideIn 0.4s ease;
                z-index: 1000;
            `;
            document.body.appendChild(successMsg);
            setTimeout(() => {
                successMsg.remove();
                document.querySelectorAll('.tab-btn')[0].click();
            }, 2000);
            e.target.reset();
        }
    </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9d81a69592ba0723',t:'MTc3MjgwMzE1NS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>