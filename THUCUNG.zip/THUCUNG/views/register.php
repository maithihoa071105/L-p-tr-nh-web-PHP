<!doctype html>
<html lang="vi">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Shop - Đăng Ký</title>
  <script src="https://cdn.tailwindcss.com/3.4.17"></script>
  <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            width: 100%;
        }

        body {
    margin: 0;
    padding: 0;
    height: 100vh;
    overflow-y: auto; /* cho phép cuộn dọc */
}

body {
    min-height: 100vh;
    overflow-y: auto;
}

.container {
    max-height: 90vh;
    overflow-y: auto;
}
.register-container{
    width:400px;
    max-height:90vh;
    overflow-y:auto;
    padding:20px;
}
        .container-auth {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-wrapper {
            display: flex;
            width: 100%;
            height: 100%;
            background: transparent;
            border-radius: 0;
            box-shadow: none;
            overflow: hidden;
            animation: slideIn 0.6s ease-out;
            justify-content: center;
            align-items: center;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .auth-right {
    width: 100%;
    max-width: 420px;
    padding: 40px;
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(255, 143, 179, 0.15);

    max-height: 90vh;
    overflow-y: auto;
}

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .form-group input:focus {
            outline: none;
            border-color: #ff8fb3;
            box-shadow: 0 0 0 3px rgba(255, 143, 179, 0.1);
        }

        .form-group input::placeholder {
            color: #999;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #ff8fb3 0%, #ffa0c4 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255, 143, 179, 0.3);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            color: #ccc;
            font-size: 13px;
        }

        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e0e0e0;
        }

        .divider::before {
            margin-right: 10px;
        }

        .divider::after {
            margin-left: 10px;
        }

        .social-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 20px;
        }

        .social-btn {
            padding: 12px;
            border: 2px solid #e0e0e0;
            background: white;
            border-radius: 10px;
            cursor: pointer;
            font-size: 22px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .social-btn:hover {
            border-color: #667eea;
            background: #f9f9f9;
            transform: translateY(-2px);
        }
        
        .social-btn.google {
            color: #4285f4;
        }
        
        .social-btn.facebook {
            color: #1877f2;
        }

        .signup-text {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }

        .signup-text a {
            color: #ff8fb3;
            text-decoration: none;
            font-weight: 700;
            cursor: pointer;
            transition: color 0.3s;
        }

        .signup-text a:hover {
            color: #ffb3d9;
        }

        @media (max-width: 768px) {
            .auth-right {
                max-width: 100%;
                border-radius: 0;
                box-shadow: none;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
  <style>body { box-sizing: border-box; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
  <script src="/_sdk/element_sdk.js" type="text/javascript"></script>
 </head>
 <body>
  <div class="container-auth">
   <div class="auth-wrapper"><!-- Signup Form -->
    <div class="auth-right"><!-- PetShop Header -->
     <div style="text-align: center; margin-bottom: 30px;">
      <h1 style="font-size: 32px; font-weight: 800; color: #ff8fb3; margin: 0;">PetShop</h1>
      <p style="font-size: 13px; color: #999; margin-top: 5px;">Đăng Ký Tài Khoản</p>
     </div>
     <form action="../actions/register.php" method="POST">

<div class="form-row">

<div class="form-group">
<label>Họ</label>
<input type="text" name="ho" placeholder="Nhập họ" required>
</div>

<div class="form-group">
<label>Tên</label>
<input type="text" name="ten" placeholder="Nhập tên" required>
</div>

</div>

<div class="form-group">
<label>Email</label>
<input type="email" name="email" placeholder="Nhập email" required>
</div>

<div class="form-group">
<label>Số điện thoại</label>
<input type="tel" name="phone" placeholder="Nhập số điện thoại" required>
</div>

<div class="form-group">
<label>Mật khẩu</label>
<input type="password" name="password" placeholder="Nhập mật khẩu" required>
</div>

<div class="form-group">
<label>Xác nhận mật khẩu</label>
<input type="password" name="repassword" placeholder="Xác nhận mật khẩu" required>
</div>

<div style="margin-bottom: 25px;">
<label style="display:flex;gap:10px;">
<input type="checkbox" required>
<span>Tôi đồng ý điều khoản</span>
</label>
</div>

<button type="submit" class="submit-btn">Đăng Ký</button>

</form>
     <div class="divider">
      Hoặc
     </div>
     <div class="social-buttons"><button type="button" class="social-btn google" title="Đăng ký với Google">G</button> <button type="button" class="social-btn facebook" title="Đăng ký với Facebook">f</button>
     </div>
     <div class="signup-text">
      Đã có tài khoản? <a href="auth.php">Đăng Nhập</a>
     </div>
    </div>
   </div>
  </div>
  <script>
    function handleSignup(e) {
      e.preventDefault();
      const successMsg = document.createElement('div');
      successMsg.textContent = '✓ Đăng ký thành công!';
      successMsg.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4caf50;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        font-weight: 600;
        animation: slideIn 0.4s ease;
        z-index: 1000;
      `;
      document.body.appendChild(successMsg);
      setTimeout(() => successMsg.remove(), 3000);
      e.target.reset();
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9d81f87551d27d73',t:'MTc3MjgwNjUwNi4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>