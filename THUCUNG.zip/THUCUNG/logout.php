<?php
session_start();

session_unset(); // xóa biến session
session_destroy(); // hủy session

echo "<script>
alert('Đăng xuất thành công!');
window.location.href='index.php';
</script>";
?>