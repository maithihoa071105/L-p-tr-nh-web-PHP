<?php

include("../config/database.php");

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_petshop.xls");

echo "ID\tKhách hàng\tTổng tiền\tTrạng thái\n";

$sql="SELECT * FROM orders";
$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_assoc($result)){

echo $row['id']."\t";
echo $row['customer_id']."\t";
echo $row['total']."\t";
echo $row['status']."\n";

}

?>