
<?php
session_start();
include("../config/database.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 1){
echo "<script>
alert('Bạn không có quyền truy cập');
window.location.href='../index.php';
</script>";
exit();
}

$search="";
if(isset($_GET['search'])){
$search=$_GET['search'];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>

<meta charset="UTF-8">
<title>Quản lý khách hàng</title>

<script src="https://cdn.tailwindcss.com"></script>

<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
*{font-family:'Be Vietnam Pro',sans-serif}
.sidebar-item{transition:0.2s}
.sidebar-item:hover{transform:translateX(4px)}
</style>

</head>

<body class="bg-blue-100">

<div class="flex h-screen">

<!-- SIDEBAR -->
<aside class="w-64 bg-blue-600 text-white flex flex-col">

<div class="p-5 border-b border-blue-400">
<h1 class="text-xl font-bold">🐾 PetShop</h1>
<p class="text-sm text-blue-200">Admin Panel</p>
</div>

<nav class="flex-1 p-4 space-y-2">

<a href="dashboard.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📊 Tổng quan
</a>

<a href="pets.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
🐶 Quản lý thú cưng
</a>

<a href="customers.php" class="sidebar-item block px-4 py-2 rounded bg-blue-500">
👥 Khách hàng
</a>

<a href="orders.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📦 Đơn hàng
</a>

<a href="accounts.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
🔐 Tài khoản
</a>

<a href="reports.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📈 Báo cáo thống kê
</a>

</nav>

<div class="p-4 border-t border-blue-400">

<p class="text-sm mb-2">
👤 <?php echo $_SESSION['username']; ?>
</p>

<a href="../logout.php" class="text-red-200 hover:text-white text-sm">
Đăng xuất
</a>

</div>

</aside>

<!-- MAIN -->
<main class="flex-1 p-6 overflow-y-auto">

<div class="flex justify-between items-center mb-6">

<h2 class="text-2xl font-bold text-gray-800">
Quản lý khách hàng
</h2>

<button onclick="openAddModal()"
class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">

➕ Thêm khách hàng

</button>

</div>

<!-- SEARCH -->
<form method="GET" class="mb-4 flex gap-2">

<input
type="text"
name="search"
value="<?php echo $search ?>"
placeholder="🔍 Tìm khách hàng..."
class="border px-3 py-2 rounded w-80">

<button class="bg-green-500 text-white px-4 py-2 rounded">
Tìm
</button>

<a href="customers.php"
class="bg-gray-400 text-white px-4 py-2 rounded">
Reset
</a>

</form>

<div class="bg-white rounded shadow overflow-x-auto">

<table class="w-full">

<thead class="bg-gray-100">

<tr>

<th class="p-3 text-left">ID</th>
<th class="p-3 text-left">Username</th>
<th class="p-3 text-left">Họ tên</th>
<th class="p-3 text-left">SĐT</th>
<th class="p-3 text-left">Địa chỉ</th>
<th class="p-3 text-center">Hành động</th>

</tr>

</thead>

<tbody>

<?php

$sql="SELECT customers.*, users.username
FROM customers
LEFT JOIN users ON customers.user_id = users.id
WHERE full_name LIKE '%$search%'";

$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){

while($row=mysqli_fetch_assoc($result)){

?>

<tr class="border-b hover:bg-blue-50">

<td class="p-3"><?php echo $row['id']; ?></td>

<td class="p-3"><?php echo $row['username']; ?></td>

<td class="p-3"><?php echo $row['full_name']; ?></td>

<td class="p-3"><?php echo $row['phone']; ?></td>

<td class="p-3"><?php echo $row['address']; ?></td>

<td class="p-3 text-center">

<button
onclick="openEditModal(
'<?php echo $row['id']; ?>',
'<?php echo $row['full_name']; ?>',
'<?php echo $row['phone']; ?>',
'<?php echo $row['address']; ?>'
)"
class="text-blue-600">

Sửa
</button>

|

<a href="../actions/delete_customer.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Bạn có chắc muốn xoá?')"
class="text-red-600">

Xóa

</a>

</td>

</tr>

<?php
}

}else{
?>

<tr>
<td colspan="6" class="text-center p-6 text-gray-500">
Chưa có khách hàng
</td>
</tr>

<?php } ?>

</tbody>

</table>

</div>

</main>

</div>

<!-- ADD MODAL -->

<div id="addModal"
class="hidden fixed inset-0 bg-black/40 flex items-center justify-center">

<div class="bg-white p-6 rounded w-96">

<h3 class="text-xl font-bold mb-4">
Thêm khách hàng
</h3>

<form action="../actions/add_customer.php" method="POST">

<input name="full_name"
placeholder="Họ tên"
class="w-full border p-2 mb-3">

<input name="phone"
placeholder="Số điện thoại"
class="w-full border p-2 mb-3">

<textarea name="address"
placeholder="Địa chỉ"
class="w-full border p-2 mb-3"></textarea>

<div class="flex justify-between">

<button type="button"
onclick="closeAddModal()"
class="bg-gray-400 text-white px-4 py-2 rounded">
Hủy
</button>

<button
class="bg-blue-500 text-white px-4 py-2 rounded">
Lưu
</button>

</div>

</form>

</div>

</div>

<!-- EDIT MODAL -->

<div id="editModal"
class="hidden fixed inset-0 bg-black/40 flex items-center justify-center">

<div class="bg-white p-6 rounded w-96">

<h3 class="text-xl font-bold mb-4">
Sửa khách hàng
</h3>

<form action="../actions/update_customer.php" method="POST">

<input type="hidden" name="id" id="edit_id">

<input name="full_name" id="edit_name"
class="w-full border p-2 mb-3">

<input name="phone" id="edit_phone"
class="w-full border p-2 mb-3">

<textarea name="address"
id="edit_address"
class="w-full border p-2 mb-3"></textarea>

<div class="flex justify-between">

<button type="button"
onclick="closeEditModal()"
class="bg-gray-400 text-white px-4 py-2 rounded">
Hủy
</button>

<button
class="bg-blue-500 text-white px-4 py-2 rounded">
Cập nhật
</button>

</div>

</form>

</div>

</div>

<script>

function openAddModal(){
document.getElementById("addModal").classList.remove("hidden")
}

function closeAddModal(){
document.getElementById("addModal").classList.add("hidden")
}

function openEditModal(id,name,phone,address){

document.getElementById("editModal").classList.remove("hidden")

document.getElementById("edit_id").value=id
document.getElementById("edit_name").value=name
document.getElementById("edit_phone").value=phone
document.getElementById("edit_address").value=address

}

function closeEditModal(){
document.getElementById("editModal").classList.add("hidden")
}

</script>

</body>
</html>

