
<?php
session_start();
include("../config/database.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 1){
echo "<script>
alert('Bạn không có quyền truy cập');
window.location.href='../index.php';
</script>";
exit();
}

// tổng thú cưng
$pets=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM pets"))['total'];

// tổng khách hàng
$customers=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM customers"))['total'];

// tổng đơn hàng
$orders=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM orders"))['total'];

// doanh thu
$revenue=mysqli_fetch_assoc(mysqli_query($conn,"SELECT SUM(total) as total FROM orders WHERE status=2"))['total'];

// dữ liệu chart
$chart=mysqli_query($conn,"
SELECT DATE(order_date) as day, SUM(total) as money
FROM orders
WHERE status=2
GROUP BY DATE(order_date)
");

$days=[];
$money=[];

while($row=mysqli_fetch_assoc($chart)){
$days[]=$row['day'];
$money[]=$row['money'];
}

?>

<!DOCTYPE html>
<html lang="vi">
<head>

<meta charset="UTF-8">
<title>Báo cáo thống kê</title>

<script src="https://cdn.tailwindcss.com"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body class="bg-blue-100">

<div class="flex h-screen">

<!-- SIDEBAR -->
<aside class="w-64 bg-blue-600 text-white flex flex-col">

<div class="p-5 border-b border-blue-400">
<h1 class="text-xl font-bold">🐾 PetShop</h1>
<p class="text-sm text-blue-200">Admin Panel</p>
</div>

<nav class="flex-1 p-4 space-y-2">

<a href="dashboard.php" class="block px-4 py-2 rounded hover:bg-blue-500">📊 Tổng quan</a>

<a href="pets.php" class="block px-4 py-2 rounded hover:bg-blue-500">🐶 Thú cưng</a>

<a href="customers.php" class="block px-4 py-2 rounded hover:bg-blue-500">👥 Khách hàng</a>

<a href="orders.php" class="block px-4 py-2 rounded hover:bg-blue-500">📦 Đơn hàng</a>

<a href="reports.php" class="block px-4 py-2 rounded bg-blue-500">📈 Báo cáo</a>

</nav>

</aside>


<!-- MAIN -->
<main class="flex-1 p-6">

<h2 class="text-2xl font-bold mb-6">Báo cáo thống kê</h2>
<div class="flex gap-3 mb-6">

<button onclick="printReport()" 
class="bg-green-500 text-white px-4 py-2 rounded">
🖨 In báo cáo
</button>

<a href="export_report.php" 
class="bg-blue-500 text-white px-4 py-2 rounded">
📄 Xuất Excel
</a>

</div>
<!-- CARDS -->
<div class="grid grid-cols-4 gap-4 mb-8">

<div class="bg-white p-4 rounded shadow">
<p class="text-gray-500">Thú cưng</p>
<h3 class="text-2xl font-bold"><?php echo $pets ?></h3>
</div>

<div class="bg-white p-4 rounded shadow">
<p class="text-gray-500">Khách hàng</p>
<h3 class="text-2xl font-bold"><?php echo $customers ?></h3>
</div>

<div class="bg-white p-4 rounded shadow">
<p class="text-gray-500">Đơn hàng</p>
<h3 class="text-2xl font-bold"><?php echo $orders ?></h3>
</div>

<div class="bg-white p-4 rounded shadow">
<p class="text-gray-500">Doanh thu</p>
<h3 class="text-2xl font-bold text-green-600">
<?php echo number_format($revenue) ?> VND
</h3>
</div>

</div>

<!-- CHART -->
<div class="bg-white p-6 rounded shadow">

<h3 class="text-lg font-semibold mb-4">
Biểu đồ doanh thu
</h3>

<canvas id="revenueChart"></canvas>

</div>

</main>

</div>


<script>

const ctx=document.getElementById('revenueChart');

new Chart(ctx,{

type:'line',

data:{
labels:<?php echo json_encode($days); ?>,

datasets:[{

label:'Doanh thu',

data:<?php echo json_encode($money); ?>,

borderColor:'blue',

backgroundColor:'rgba(0,0,255,0.1)',

tension:0.4,

fill:true

}]

}

})

</script>
<script>

function printReport(){

var content=document.querySelector("main").innerHTML;

var win=window.open("","","width=900,height=700");

win.document.write("<html><head>");
win.document.write("<title>Báo cáo PetShop</title>");
win.document.write("</head><body>");
win.document.write("<h2>Báo cáo thống kê PetShop</h2>");
win.document.write(content);
win.document.write("</body></html>");

win.document.close();
win.print();

}

</script>

</div>
</body>
</html>

