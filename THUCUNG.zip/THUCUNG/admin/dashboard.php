<?php
session_start();

if(!isset($_SESSION['role']) || $_SESSION['role'] != 1){

    echo "<script>
    alert('Bạn không có quyền truy cập');
    window.location.href='../index.php';
    </script>";

    exit();
}
?>

<!doctype html>
<html lang="vi" class="h-full">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Shop Admin</title>
  <script src="https://cdn.tailwindcss.com/3.4.17"></script>
  <script src="/_sdk/element_sdk.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">
  <style>
    * { font-family: 'Be Vietnam Pro', sans-serif; }
    .sidebar-item { transition: all 0.2s ease; }
    .sidebar-item:hover { transform: translateX(4px); }
    .card-hover { transition: all 0.3s ease; }
    .card-hover:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(59, 130, 246, 0.15); }
    .stat-icon { animation: pulse-soft 2s infinite; }
    @keyframes pulse-soft {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }
    .table-row { transition: background-color 0.2s ease; }
    .btn-action { transition: all 0.2s ease; }
    .btn-action:hover { transform: scale(1.05); }
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #f1f5f9; }
    ::-webkit-scrollbar-thumb { background: #94a3b8; border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: #64748b; }
  </style>
  <style>body { box-sizing: border-box; }</style>
  <script src="/_sdk/data_sdk.js" type="text/javascript"></script>
 </head>
 <body class="h-full bg-gradient-to-br from-blue-100 via-cyan-100 to-blue-200">
  <div class="flex h-full overflow-hidden">
   <!-- Sidebar -->
   <!-- Sidebar -->
<aside class="w-64 bg-gradient-to-b from-blue-500 to-blue-700 text-white flex flex-col flex-shrink-0">

<!-- Logo -->
<div class="p-5 border-b border-blue-400/30">
<div class="flex items-center gap-3">
<div class="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
<span class="text-2xl">🐾</span>
</div>

<div>
<h1 id="shop-name" class="font-bold text-lg">PetShop</h1>
<p class="text-blue-100 text-xs">Quản trị viên</p>
</div>
</div>
</div>

<!-- Navigation -->
<nav class="flex-1 p-4 space-y-2 overflow-y-auto">

<a href="dashboard.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl bg-white/20 text-white font-medium">
<span class="text-xl">📊</span>
<span>Tổng quan</span>
</a>

<a href="pets.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl text-blue-100 hover:bg-white/10">
<span class="text-xl">🐕</span>
<span>Thú cưng</span>
</a>

<a href="customers.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl text-blue-100 hover:bg-white/10">
<span class="text-xl">👥</span>
<span>Khách hàng</span>
</a>

<a href="orders.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl text-blue-100 hover:bg-white/10">
<span class="text-xl">📦</span>
<span>Đơn hàng</span>
</a>

<a href="accounts.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl text-blue-100 hover:bg-white/10">
<span class="text-xl">🔐</span>
<span>Tài khoản</span>
</a>

<a href="reports.php" class="sidebar-item flex items-center gap-3 px-4 py-3 rounded-xl text-blue-100 hover:bg-white/10">
<span class="text-xl">📈</span>
<span>Báo cáo</span>
</a>

</nav>

<!-- User -->
<div class="p-4 border-t border-blue-400/30">

<div class="flex items-center gap-3 px-3 py-2 rounded-xl bg-white/10">

<div class="w-9 h-9 bg-blue-400 rounded-full flex items-center justify-center text-white font-bold text-sm">
A
</div>

<div class="flex-1 min-w-0">
<p class="font-medium text-sm truncate">
<?php echo $_SESSION['username']; ?>
</p>
<p class="text-blue-100 text-xs">Quản trị viên</p>
</div>

<a href="../logout.php"
class="text-blue-100 hover:text-white transition-colors"
title="Đăng xuất">

<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
</svg>

</a>

</div>
</div>

</aside><!-- Main Content -->
   <main class="flex-1 flex flex-col min-w-0 overflow-hidden">
    <!-- Header -->
    <header class="bg-white/80 backdrop-blur-sm border-b border-blue-200 px-6 py-4 flex-shrink-0">
     <div class="flex items-center justify-between">
      <div>
       <h2 id="page-title" class="text-2xl font-bold text-slate-800">Tổng quan</h2>
       <p class="text-slate-500 text-sm mt-0.5">Chào mừng trở lại! Đây là tình hình cửa hàng hôm nay.</p>
      </div>
      <div class="flex items-center gap-4">
       <!-- Search -->
       <div class="relative">
        <input type="text" placeholder="Tìm kiếm..." class="pl-10 pr-4 py-2 w-64 bg-blue-50 border-0 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:bg-white transition-all">
        <svg class="w-5 h-5 text-blue-300 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewbox="0 0 24 24">
         <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
       </div><!-- Notifications --> <button class="relative p-2 text-blue-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewbox="0 0 24 24">
         <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg><span class="absolute top-1 right-1 w-2.5 h-2.5 bg-red-400 rounded-full border-2 border-white"></span> </button> <!-- Date -->
       <div class="text-right">
        <p class="text-sm font-medium text-slate-700" id="current-date">--</p>
        <p class="text-xs text-blue-400" id="current-time">--</p>
       </div>
      </div>
     </div>
    </header><!-- Content Area -->
    <div class="flex-1 p-6 overflow-y-auto">
     <!-- Stats Cards -->
     <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-6">
      <!-- Total Revenue -->
      <div class="card-hover bg-white rounded-2xl p-5 border border-blue-100 shadow-sm">
       <div class="flex items-start justify-between">
        <div>
         <p class="text-blue-600 text-sm font-medium">Doanh thu tháng</p>
         <p class="text-2xl font-bold text-slate-800 mt-1">125.8M</p>
         <p class="text-green-500 text-sm mt-2 flex items-center gap-1">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewbox="0 0 24 24">
           <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12" />
          </svg> +12.5% so với tháng trước</p>
        </div>
        <div class="stat-icon w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center">
         <span class="text-2xl">💰</span>
        </div>
       </div>
      </div><!-- Total Orders -->
      <div class="card-hover bg-white rounded-2xl p-5 border border-blue-100 shadow-sm">
       <div class="flex items-start justify-between">
        <div>
         <p class="text-cyan-600 text-sm font-medium">Đơn hàng mới</p>
         <p class="text-2xl font-bold text-slate-800 mt-1">48</p>
         <p class="text-green-500 text-sm mt-2 flex items-center gap-1">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewbox="0 0 24 24">
           <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12" />
          </svg> +8 đơn hôm nay</p>
        </div>
        <div class="stat-icon w-12 h-12 bg-gradient-to-br from-cyan-400 to-cyan-500 rounded-xl flex items-center justify-center">
         <span class="text-2xl">📦</span>
        </div>
       </div>
      </div><!-- Total Pets -->
      <div class="card-hover bg-white rounded-2xl p-5 border border-blue-100 shadow-sm">
       <div class="flex items-start justify-between">
        <div>
         <p class="text-blue-500 text-sm font-medium">Thú cưng có sẵn</p>
         <p class="text-2xl font-bold text-slate-800 mt-1">156</p>
         <p class="text-amber-500 text-sm mt-2 flex items-center gap-1"><span>🐕 89 chó</span> <span class="mx-1">•</span> <span>🐈 67 mèo</span></p>
        </div>
        <div class="stat-icon w-12 h-12 bg-gradient-to-br from-amber-300 to-amber-400 rounded-xl flex items-center justify-center">
         <span class="text-2xl">🐾</span>
        </div>
       </div>
      </div><!-- Total Customers -->
      <div class="card-hover bg-white rounded-2xl p-5 border border-blue-100 shadow-sm">
       <div class="flex items-start justify-between">
        <div>
         <p class="text-purple-600 text-sm font-medium">Khách hàng</p>
         <p class="text-2xl font-bold text-slate-800 mt-1">1,234</p>
         <p class="text-blue-500 text-sm mt-2 flex items-center gap-1">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewbox="0 0 24 24">
           <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
          </svg> +23 khách mới</p>
        </div>
        <div class="stat-icon w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center">
         <span class="text-2xl">👥</span>
        </div>
       </div>
      </div>
     </div><!-- Main Grid -->
     <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <!-- Top Selling Pets -->
      <div class="bg-white rounded-2xl border border-blue-100 shadow-sm p-5">
       <h3 class="font-bold text-slate-800 flex items-center gap-2 mb-4"><span class="text-lg">🏆</span> Thú cưng bán chạy</h3>
       <div class="space-y-3">
        <div class="flex items-center gap-3 p-3 bg-gradient-to-r from-amber-50 to-transparent rounded-xl">
         <div class="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center text-lg">
          🥇
         </div>
         <div class="flex-1">
          <p class="font-medium text-slate-700 text-sm">Corgi</p>
          <p class="text-slate-400 text-xs">32 đã bán</p>
         </div><span class="text-sm font-bold text-amber-600">8.5M</span>
        </div>
        <div class="flex items-center gap-3 p-3 bg-gradient-to-r from-slate-50 to-transparent rounded-xl">
         <div class="w-10 h-10 bg-slate-200 rounded-xl flex items-center justify-center text-lg">
          🥈
         </div>
         <div class="flex-1">
          <p class="font-medium text-slate-700 text-sm">Mèo Anh lông ngắn</p>
          <p class="text-slate-400 text-xs">28 đã bán</p>
         </div><span class="text-sm font-bold text-slate-600">6.2M</span>
        </div>
        <div class="flex items-center gap-3 p-3 bg-gradient-to-r from-orange-50 to-transparent rounded-xl">
         <div class="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center text-lg">
          🥉
         </div>
         <div class="flex-1">
          <p class="font-medium text-slate-700 text-sm">Golden Retriever</p>
          <p class="text-slate-400 text-xs">24 đã bán</p>
         </div><span class="text-sm font-bold text-orange-600">12M</span>
        </div>
        <div class="flex items-center gap-3 p-3 hover:bg-blue-50 rounded-xl transition-colors">
         <div class="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-lg">
          🐕
         </div>
         <div class="flex-1">
          <p class="font-medium text-slate-700 text-sm">Poodle</p>
          <p class="text-slate-400 text-xs">21 đã bán</p>
         </div><span class="text-sm font-bold text-blue-600">7.5M</span>
        </div>
       </div>
      </div><!-- Revenue Chart -->
      <div class="bg-white rounded-2xl border border-blue-100 shadow-sm p-5">
       <h3 class="font-bold text-slate-800 flex items-center gap-2 mb-4"><span class="text-lg">📈</span> Doanh thu 7 ngày qua</h3>
       <div class="space-y-3">
        <div class="flex items-end gap-2 h-32 px-2">
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-200 to-blue-300 rounded-t-lg" style="height: 45%"></div><span class="text-xs text-slate-400">T2</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-300 to-blue-400 rounded-t-lg" style="height: 60%"></div><span class="text-xs text-slate-400">T3</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-200 to-blue-300 rounded-t-lg" style="height: 35%"></div><span class="text-xs text-slate-400">T4</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-400 to-blue-500 rounded-t-lg" style="height: 75%"></div><span class="text-xs text-slate-400">T5</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-500 to-blue-600 rounded-t-lg" style="height: 90%"></div><span class="text-xs text-slate-400">T6</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-cyan-500 to-cyan-600 rounded-t-lg" style="height: 100%"></div><span class="text-xs text-slate-400">T7</span>
         </div>
         <div class="flex-1 flex flex-col items-center gap-1">
          <div class="w-full bg-gradient-to-t from-blue-400 to-blue-500 rounded-t-lg" style="height: 70%"></div><span class="text-xs text-slate-400">CN</span>
         </div>
        </div>
        <div class="flex items-center justify-between pt-3 border-t border-blue-100">
         <span class="text-sm text-slate-500">Tổng tuần này</span> <span class="text-lg font-bold text-blue-600">42.5M</span>
        </div>
       </div>
      </div>
     </div>
    </div>
   </main>
  </div>
  <script>
    // Default configuration
    const defaultConfig = {
      shop_name: 'PetShop Pro',
      admin_name: 'Admin User',
      background_color: '#e0f2fe',
      primary_color: '#3b82f6',
      text_color: '#1e293b',
      card_color: '#ffffff',
      accent_color: '#06b6d4'
    };

    // Update date/time
    function updateDateTime() {
      const now = new Date();
      const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      const timeOptions = { hour: '2-digit', minute: '2-digit' };
      
      document.getElementById('current-date').textContent = now.toLocaleDateString('vi-VN', dateOptions);
      document.getElementById('current-time').textContent = now.toLocaleTimeString('vi-VN', timeOptions);
    }
    
    updateDateTime();
    setInterval(updateDateTime, 60000);

    // Sidebar navigation
    document.querySelectorAll('[data-section]').forEach(item => {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Update active state
        document.querySelectorAll('[data-section]').forEach(el => {
          el.classList.remove('bg-white/20', 'text-white', 'font-medium');
          el.classList.add('text-blue-100');
        });
        this.classList.add('bg-white/20', 'text-white', 'font-medium');
        this.classList.remove('text-blue-100');
        
        // Update page title
        const sectionNames = {
          'dashboard': 'Tổng quan',
          'pets': 'Quản lý thú cưng',
          'customers': 'Quản lý khách hàng',
          'orders': 'Quản lý đơn hàng',
          'accounts': 'Quản lý tài khoản',
          'reports': 'Báo cáo thống kê'
        };
        document.getElementById('page-title').textContent = sectionNames[this.dataset.section] || 'Tổng quan';
      });
    });

    // Element SDK Integration
    async function onConfigChange(config) {
      const shopName = config.shop_name || defaultConfig.shop_name;
      const adminName = config.admin_name || defaultConfig.admin_name;
      const bgColor = config.background_color || defaultConfig.background_color;
      const primaryColor = config.primary_color || defaultConfig.primary_color;
      const textColor = config.text_color || defaultConfig.text_color;
      const cardColor = config.card_color || defaultConfig.card_color;
      const accentColor = config.accent_color || defaultConfig.accent_color;

      document.getElementById('shop-name').textContent = shopName;
      document.getElementById('admin-name').textContent = adminName;
      
      // Apply colors
      document.body.style.background = `linear-gradient(to bottom right, ${bgColor}, #cffafe)`;
      
      document.querySelectorAll('.card-hover, .bg-white').forEach(el => {
        if (el.classList.contains('rounded-2xl') || el.classList.contains('rounded-xl')) {
          el.style.backgroundColor = cardColor;
        }
      });
    }

    function mapToCapabilities(config) {
      return {
        recolorables: [
          {
            get: () => config.background_color || defaultConfig.background_color,
            set: (value) => {
              config.background_color = value;
              if (window.elementSdk) window.elementSdk.setConfig({ background_color: value });
            }
          },
          {
            get: () => config.card_color || defaultConfig.card_color,
            set: (value) => {
              config.card_color = value;
              if (window.elementSdk) window.elementSdk.setConfig({ card_color: value });
            }
          },
          {
            get: () => config.text_color || defaultConfig.text_color,
            set: (value) => {
              config.text_color = value;
              if (window.elementSdk) window.elementSdk.setConfig({ text_color: value });
            }
          },
          {
            get: () => config.primary_color || defaultConfig.primary_color,
            set: (value) => {
              config.primary_color = value;
              if (window.elementSdk) window.elementSdk.setConfig({ primary_color: value });
            }
          },
          {
            get: () => config.accent_color || defaultConfig.accent_color,
            set: (value) => {
              config.accent_color = value;
              if (window.elementSdk) window.elementSdk.setConfig({ accent_color: value });
            }
          }
        ],
        borderables: [],
        fontEditable: undefined,
        fontSizeable: undefined
      };
    }

    function mapToEditPanelValues(config) {
      return new Map([
        ['shop_name', config.shop_name || defaultConfig.shop_name],
        ['admin_name', config.admin_name || defaultConfig.admin_name]
      ]);
    }

    // Initialize Element SDK
    if (window.elementSdk) {
      window.elementSdk.init({
        defaultConfig,
        onConfigChange,
        mapToCapabilities,
        mapToEditPanelValues
      });
    } else {
      onConfigChange(defaultConfig);
    }
  </script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9d87d4e801770723',t:'MTc3Mjg2Nzk2NC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>

