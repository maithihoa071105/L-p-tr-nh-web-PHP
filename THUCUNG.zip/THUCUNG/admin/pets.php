
<?php
session_start();
include("../config/database.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 1){
echo "<script>
alert('Bạn không có quyền truy cập');
window.location.href='../index.php';
</script>";
exit();
}

$search = "";
if(isset($_GET['search'])){
$search = $_GET['search'];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý thú cưng</title>

<script src="https://cdn.tailwindcss.com"></script>

<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
*{font-family:'Be Vietnam Pro',sans-serif}
.sidebar-item{transition:0.2s}
.sidebar-item:hover{transform:translateX(4px)}
</style>

</head>

<body class="bg-blue-100">

<div class="flex h-screen">

<!-- SIDEBAR -->
<aside class="w-64 bg-blue-600 text-white flex flex-col">

<div class="p-5 border-b border-blue-400">
<h1 class="text-xl font-bold">🐾 PetShop</h1>
<p class="text-sm text-blue-200">Admin Panel</p>
</div>

<nav class="flex-1 p-4 space-y-2">

<a href="dashboard.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📊 Tổng quan
</a>

<a href="pets.php" class="sidebar-item block px-4 py-2 rounded bg-blue-500">
🐶 Quản lý thú cưng
</a>

<a href="customers.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
👥 Khách hàng
</a>

<a href="orders.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📦 Đơn hàng
</a>

<a href="accounts.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
🔐 Tài khoản
</a>

<a href="reports.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📈 Báo cáo thống kê
</a>

</nav>

<div class="p-4 border-t border-blue-400">

<p class="text-sm mb-2">
👤 <?php echo $_SESSION['username']; ?>
</p>

<a href="../logout.php" class="text-red-200 hover:text-white text-sm">
Đăng xuất
</a>

</div>

</aside>

<!-- MAIN -->
<main class="flex-1 p-6 overflow-y-auto">

<div class="flex justify-between items-center mb-6">

<h2 class="text-2xl font-bold text-gray-800">
Quản lý thú cưng
</h2>

<button onclick="openAddModal()"
class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
➕ Thêm thú cưng
</button>

</div>

<!-- SEARCH -->
<form method="GET" class="mb-4 flex gap-2">

<input type="text"
name="search"
value="<?php echo $search ?>"
placeholder="🔍 Tìm tên thú cưng..."
class="border px-3 py-2 rounded w-80">

<button class="bg-green-500 text-white px-4 py-2 rounded">
Tìm
</button>

<a href="pets.php"
class="bg-gray-400 text-white px-4 py-2 rounded">
Reset
</a>

</form>

<div class="bg-white rounded shadow overflow-x-auto">

<table class="w-full">

<thead class="bg-gray-100">

<tr>
<th class="p-3 text-left">ID</th>
<th class="p-3 text-left">Tên</th>
<th class="p-3 text-left">Danh mục</th>
<th class="p-3 text-left">Giá</th>
<th class="p-3 text-left">Tồn kho</th>
<th class="p-3 text-left">Trạng thái</th>
<th class="p-3 text-center">Hành động</th>
</tr>

</thead>

<tbody>

<?php

$sql="SELECT pets.*, categories.name AS category_name
FROM pets
LEFT JOIN categories ON pets.category_id = categories.id
WHERE pets.name LIKE '%$search%'";

$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){

while($row=mysqli_fetch_assoc($result)){

?>

<tr class="border-b hover:bg-blue-50">

<td class="p-3"><?php echo $row['id']; ?></td>

<td class="p-3 font-medium"><?php echo $row['name']; ?></td>

<td class="p-3"><?php echo $row['category_name']; ?></td>

<td class="p-3"><?php echo number_format($row['price']); ?> VND</td>

<td class="p-3"><?php echo $row['stock']; ?></td>

<td class="p-3">

<?php
if($row['status']==1){
echo "<span class='text-green-600 font-medium'>Hiển thị</span>";
}else{
echo "<span class='text-red-500'>Ẩn</span>";
}
?>

</td>

<td class="p-3 text-center">

<button
onclick="openEditModal(
'<?php echo $row['id']; ?>',
'<?php echo $row['name']; ?>',
'<?php echo $row['category_id']; ?>',
'<?php echo $row['price']; ?>',
'<?php echo $row['stock']; ?>',
'<?php echo $row['status']; ?>'
)"
class="text-blue-600">

Sửa
</button>

|

<a href="../actions/delete_pet.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Bạn có chắc muốn xoá?')"
class="text-red-600">

Xóa
</a>

</td>

</tr>

<?php
}

}else{

?>

<tr>
<td colspan="7" class="text-center p-6 text-gray-500">
Chưa có thú cưng
</td>
</tr>

<?php } ?>

</tbody>

</table>

</div>

</main>

</div>


<!-- ADD MODAL -->

<div id="addModal"
class="hidden fixed inset-0 bg-black/40 flex items-center justify-center">

<div class="bg-white p-6 rounded w-96">

<h3 class="text-xl font-bold mb-4">
Thêm thú cưng
</h3>

<form action="../actions/add_pet.php"
method="POST"
enctype="multipart/form-data">

<input name="name"
placeholder="Tên thú cưng"
class="w-full border p-2 mb-3">

<select name="category_id"
class="w-full border p-2 mb-3">

<option value="">Chọn danh mục</option>

<?php
$cat=mysqli_query($conn,"SELECT * FROM categories");
while($c=mysqli_fetch_assoc($cat)){
echo "<option value='{$c['id']}'>{$c['name']}</option>";
}
?>

</select>

<input name="price"
placeholder="Giá"
class="w-full border p-2 mb-3">

<input name="stock"
placeholder="Số lượng"
class="w-full border p-2 mb-3">

<input type="file"
name="image"
class="mb-3">

<div class="flex justify-between">

<button type="button"
onclick="closeAddModal()"
class="bg-gray-400 text-white px-4 py-2 rounded">
Hủy
</button>

<button
class="bg-blue-500 text-white px-4 py-2 rounded">
Lưu
</button>

</div>

</form>

</div>

</div>

<!-- EDIT MODAL -->

<div id="editModal"
class="hidden fixed inset-0 bg-black/40 flex items-center justify-center">

<div class="bg-white p-6 rounded w-96">

<h3 class="text-xl font-bold mb-4">
Sửa thú cưng
</h3>

<form action="../actions/update_pet.php" method="POST">

<input type="hidden" name="id" id="edit_id">

<input name="name" id="edit_name"
class="w-full border p-2 mb-3">

<select name="category_id"
id="edit_category"
class="w-full border p-2 mb-3">

<?php
$cat=mysqli_query($conn,"SELECT * FROM categories");
while($c=mysqli_fetch_assoc($cat)){
echo "<option value='{$c['id']}'>{$c['name']}</option>";
}
?>

</select>

<input name="price" id="edit_price"
class="w-full border p-2 mb-3">

<input name="stock" id="edit_stock"
class="w-full border p-2 mb-3">

<select name="status" id="edit_status"
class="w-full border p-2 mb-3">

<option value="1">Hiển thị</option>
<option value="0">Ẩn</option>

</select>

<div class="flex justify-between">

<button type="button"
onclick="closeEditModal()"
class="bg-gray-400 text-white px-4 py-2 rounded">
Hủy
</button>

<button
class="bg-blue-500 text-white px-4 py-2 rounded">
Cập nhật
</button>

</div>

</form>

</div>

</div>

<script>

function openAddModal(){
document.getElementById("addModal").classList.remove("hidden")
}

function closeAddModal(){
document.getElementById("addModal").classList.add("hidden")
}

function openEditModal(id,name,category,price,stock,status){

document.getElementById("editModal").classList.remove("hidden")

document.getElementById("edit_id").value=id
document.getElementById("edit_name").value=name
document.getElementById("edit_category").value=category
document.getElementById("edit_price").value=price
document.getElementById("edit_stock").value=stock
document.getElementById("edit_status").value=status

}

function closeEditModal(){
document.getElementById("editModal").classList.add("hidden")
}

</script>

</body>
</html>
```
