
<?php
session_start();
include("../config/database.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 1){
    echo "<script>
    alert('Bạn không có quyền truy cập');
    window.location.href='../index.php';
    </script>s";
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
<meta charset="UTF-8">
<title>Quản lý đơn hàng</title>

<script src="https://cdn.tailwindcss.com"></script>

<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600&display=swap" rel="stylesheet">

<style>
*{font-family:'Be Vietnam Pro',sans-serif}
</style>

</head>

<body class="bg-blue-100">

<div class="flex h-screen">

<!-- SIDEBAR -->
<aside class="w-64 bg-blue-600 text-white flex flex-col">

<div class="p-5 border-b border-blue-400">
<h1 class="text-xl font-bold">🐾 PetShop</h1>
<p class="text-sm text-blue-200">Admin Panel</p>
</div>

<nav class="flex-1 p-4 space-y-2">

<a href="dashboard.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📊 Tổng quan
</a>

<a href="pets.php" class="sidebar-item block px-4 py-2 rounded bg-blue-500">
🐶 Quản lý thú cưng
</a>

<a href="customers.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
👥 Khách hàng
</a>

<a href="orders.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📦 Đơn hàng
</a>

<a href="accounts.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
🔐 Tài khoản
</a>

<a href="reports.php" class="sidebar-item block px-4 py-2 rounded hover:bg-blue-500">
📈 Báo cáo thống kê
</a>

</nav>

<div class="p-4 border-t border-blue-400">
<p class="text-sm mb-2">👤 <?php echo $_SESSION['username']; ?></p>
<a href="../logout.php" class="text-red-200 hover:text-white text-sm">Đăng xuất</a>
</div>

</aside>


<!-- MAIN -->
<main class="flex-1 p-6 overflow-y-auto">

<h2 class="text-2xl font-bold mb-4">Quản lý đơn hàng</h2>

<!-- SEARCH -->
<input type="text" id="search"
placeholder="Tìm đơn hàng..."
class="mb-4 p-2 border rounded w-64">

<div class="bg-white rounded shadow overflow-x-auto">

<table class="w-full">

<thead class="bg-gray-100">

<tr>
<th class="p-3">ID</th>
<th class="p-3">Khách hàng</th>
<th class="p-3">Tổng tiền</th>
<th class="p-3">Ngày</th>
<th class="p-3">Trạng thái</th>
<th class="p-3 text-center">Hành động</th>
</tr>

</thead>

<tbody id="orderTable">

<?php

$sql="SELECT * FROM orders";
$result=mysqli_query($conn,$sql);

while($row=mysqli_fetch_assoc($result)){
?>

<tr class="border-b">

<td class="p-3"><?php echo $row['id']; ?></td>

<td class="p-3"><?php echo $row['customer_id']; ?></td>

<td class="p-3"><?php echo number_format($row['total']); ?> VND</td>

<td class="p-3"><?php echo $row['order_date']; ?></td>

<td class="p-3">

<?php
if($row['status']==0){
echo "<span class='text-yellow-600'>Chờ xử lý</span>";
}elseif($row['status']==1){
echo "<span class='text-blue-600'>Đang giao</span>";
}else{
echo "<span class='text-green-600'>Hoàn thành</span>";
}
?>

</td>

<td class="p-3 text-center">

<button onclick="openEdit(
'<?php echo $row['id']; ?>',
'<?php echo $row['status']; ?>'
)"
class="text-blue-600">Sửa</button>

|

<a href="../actions/delete_order.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Xóa đơn hàng?')"
class="text-red-600">
Xóa
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</main>

</div>

<!-- MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center">

<div class="bg-white p-6 rounded w-96">

<h3 class="text-lg font-bold mb-4">Cập nhật trạng thái</h3>

<form action="../actions/update_order.php" method="POST">

<input type="hidden" name="id" id="order_id">

<select name="status" id="status"
class="border p-2 w-full mb-4">

<option value="0">Chờ xử lý</option>
<option value="1">Đang giao</option>
<option value="2">Hoàn thành</option>

</select>

<div class="flex justify-end gap-2">

<button type="button"
onclick="closeModal()"
class="px-3 py-1 bg-gray-300 rounded">
Hủy
</button>

<button class="px-3 py-1 bg-blue-500 text-white rounded">
Lưu
</button>

</div>

</form>

</div>
</div>

<script>

function openEdit(id,status){
document.getElementById("editModal").classList.remove("hidden");
document.getElementById("order_id").value=id;
document.getElementById("status").value=status;
}

function closeModal(){
document.getElementById("editModal").classList.add("hidden");
}

// SEARCH

document.getElementById("search").addEventListener("keyup",function(){

let filter=this.value.toLowerCase();
let rows=document.querySelectorAll("#orderTable tr");

rows.forEach(row=>{
row.style.display=row.innerText.toLowerCase().includes(filter)?"":"none";
})

})

</script>

</body>
</html>

